package com.varsitycollege.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    //Granny,Cats
    //Grandpa,Dog
    //Grandchild,FishP
    Button btnHello;
    TextView tvHname;
    EditText txtName;
    EditText txtPassword;
    TextView txtPasswordDisplay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[][] Details={
                {"Granny", "Cats"},
                {"Grandpa", "Dogs"},
                {"Grandchild","FishP"}
        };


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtName = (EditText) findViewById(R.id.txtName);
        txtPassword = (EditText) findViewById(R.id.txtPasswordIn);
        tvHname = (TextView) findViewById(R.id.txtNameDisplay);
        txtPasswordDisplay =(TextView) findViewById(R.id.txtPasswordDisplay);
        btnHello = (Button) findViewById(R.id.btnSubmit);

        btnHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strUser = txtName.getText().toString();
                tvHname.setText( "Your username is: "+strUser);
                String strPassword = txtPassword.getText().toString();
                txtPasswordDisplay.setText("Your password is: "+strPassword);

                for(int x=0;x<Details.length;x++)
                {
                    if(Details[x][0].equals(txtName.getText().toString()) || Details[x][1].equals(txtPassword.getText().toString()))
                    {
                        txtPasswordDisplay.setText("Welcome " + Details[x][0]);
                    }
                    else
                    {
                        txtPasswordDisplay.setText("Wrong details");
                        Toast.makeText(MainActivity.this, "Unsuccessful", Toast.LENGTH_SHORT).show();
                    }

                }

            }

        });




    }
    /*public void onBtnClick(View view)
    {
        final ArrayList<String> Users = new ArrayList<>();
        final ArrayList<String> Passwords = new ArrayList<>();

        Users.add("Grandma");
        Users.add("Grandpa");
        Users.add("Grandchild");

        Passwords.add("Cats");
        Passwords.add("Dog");
        Passwords.add("FishP");
        for(int i = 0; i<Users.length(); i++)
        {
            if(txtName.equals(Users.contains("Grandma")) && txtPassword.equals(Passwords.contains("Cats")))
            {
                Toast.makeText(this, "Succesfull grandma", Toast.LENGTH_SHORT).show();
            }
            if(txtName.equals(Users.contains("Grandpa")) && txtPassword.equals(Passwords.contains("Dogs")))
            {
                Toast.makeText(this, "Succesfull grandpa", Toast.LENGTH_SHORT).show();
            }
            if(txtName.equals(Users.contains("Grandchild")) && txtPassword.equals(Passwords.contains("FishP")))
            {
                Toast.makeText(this, "Succesfull grand kid", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this, "Unsuccessful", Toast.LENGTH_SHORT).show();
            }
        }
    }*/


}